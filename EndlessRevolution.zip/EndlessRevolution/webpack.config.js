module.exports = {
  entry: "./lib/endless.js",
  output: {
  	filename: "./lib/bundle.js"
  },
  devtool: 'source-map',
};
